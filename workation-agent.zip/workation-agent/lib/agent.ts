import { z } from 'zod';
import type { WorkationRequest } from './data';

export const MODEL = process.env.AI_MODEL || 'anthropic/claude-sonnet-4.5';

// Rule-based checks. These decide whether Approve is available.
// The model explains them; it can't switch them off.
export type Check = { id: string; severity: 'blocking' | 'warning'; title: string; detail: string };

export function ruleChecks(r: WorkationRequest): Check[] {
  const out: Check[] = [];
  if (r.dates.start < r.submitted) {
    out.push({ id: 'past-dates', severity: 'blocking', title: 'Trip dates are before the request was submitted', detail: `Trip starts ${r.dates.start}, request submitted ${r.submitted}.` });
  }
  const tripYear = Number(r.dates.start.slice(0, 4));
  if (tripYear !== r.daysAbroad.year) {
    out.push({ id: 'year-mismatch', severity: 'blocking', title: 'Days abroad counted against the wrong year', detail: `Trip is in ${tripYear}, balance shown for ${r.daysAbroad.year}.` });
  }
  const unreachable = r.sourceChecks.filter((s) => s.status === 'unreachable');
  for (const s of unreachable) out.push({ id: 'unreachable-' + s.name, severity: 'warning', title: `${s.name} couldn't be verified`, detail: 'Source did not respond.' });
  return out;
}

export function canApprove(r: WorkationRequest) {
  const stepsOk = r.steps.every((s) => s.state === 'Done' || s.state === 'Needs you');
  const blocking = ruleChecks(r).some((c) => c.severity === 'blocking');
  const waiting = r.steps.some((s) => s.state === 'Working' || s.state === 'Waiting' || s.state === 'Blocked');
  return stepsOk && !blocking && !waiting;
}

export const SYSTEM = `You are the approvals agent inside a Workation (work abroad) tool used by Global Mobility and HR admins.
Your reader is Laura, a Global Mobility and Compliance Manager. She must be able to defend every decision to an auditor.

Rules you never break:
- You never approve, reject or cancel. Laura decides. Don't tell her what to decide; tell her what is true and what is missing.
- Use only the request data you are given. Never invent documents, dates, people, laws or numbers.
- Risk levels come from the rules engine. Don't change them. Explain them.
- If something could not be verified, say so plainly. An incomplete summary must say it is incomplete.
- Cite sources by their exact names from the data (documents, steps, rules like BT_WE_12).

Writing style: plain English, short sentences, action first. No filler, no hedging words like "it seems". No em dashes.`;

export const AssessmentSchema = z.object({
  headline: z.string().describe('Max 8 words. What Laura should know first. Examples: "Ready for your decision", "Check one thing before you decide", "Approval paused: dates need a fix", "The agent is collecting 1 document".'),
  summary: z.string().describe('1 or 2 sentences, max 35 words. Why, in plain words.'),
  confidenceNote: z.string().describe('One line about evidence, like "4 of 4 sources checked and current." or "3 of 4 sources checked. 1 couldn\'t be reached, so this summary is incomplete."'),
  anomalies: z
    .array(
      z.object({
        title: z.string().describe('Max 8 words'),
        detail: z.string().describe('One sentence with the concrete values from the data'),
        suggestedAction: z.string().describe('What Laura can do next, starting with a verb'),
      }),
    )
    .describe('Data problems: past dates, balance for the wrong year, missing or unverified documents, anything inconsistent. Empty if none.'),
  sources: z.array(z.string()).describe('Exact names of the documents, steps and rules you relied on'),
});
export type Assessment = z.infer<typeof AssessmentSchema>;

export function requestContext(r: WorkationRequest) {
  return JSON.stringify({ request: r, ruleChecks: ruleChecks(r), approveAvailable: canApprove(r) }, null, 2);
}
